def add_number(num):
	return num + 1
